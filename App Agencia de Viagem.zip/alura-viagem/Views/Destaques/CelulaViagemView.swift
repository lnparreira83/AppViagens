//
//  CelulaViagemView.swift
//  alura-viagem
//
//  Created by Lucas Parreira on 12/04/21.
//

import SwiftUI

struct CelulaViagemView: View {
    var viagem : Viagem
    @Environment(\.horizontalSizeClass) var horizontalSizeClass
    var body: some View {
        VStack(alignment: .leading){
            Text(viagem.titulo).padding(.top,20).font(.custom("Avenir Black",size: self.horizontalSizeClass == .compact ? 14 : 24))
                
            Image(viagem.imagem)
                .resizable()
                .aspectRatio(contentMode: .fill)
                .frame(height:self.horizontalSizeClass == .compact ? 125 : 200)
                .clipped()
                
            HStack{
                Text(viagem.quantidadeDeDias).font(.custom("Avenir Black",size: self.horizontalSizeClass == .compact ? 12 : 20))
                Spacer()
                Text("R$ \(viagem.valor)").font(.custom("Avenir Black",size: self.horizontalSizeClass == .compact ? 12 : 20))
            }
        }
    }
}

struct CelulaViagemView_Previews: PreviewProvider {
    static var previews: some View {
        CelulaViagemView(viagem: viagens[0])
    }
}
