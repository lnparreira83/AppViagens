//
//  SecaoPacoteView.swift
//  alura-viagem
//
//  Created by Lucas Parreira on 13/04/21.
//

import SwiftUI

struct SecaoPacoteView: View {
    // MARK :- Atributos
    var nomeDaSecao : String
    var pacotes: [PacoteDeViagem]
    
    var body: some View {
       
        VStack(alignment:.leading){
            Text(self.nomeDaSecao)
                .font(.headline)
                .padding(.leading,15)
                .padding(.top,5)
           ScrollView(.horizontal,showsIndicators:false){
          
                HStack{
                    
                    ForEach(self.pacotes){pacote in
                        NavigationLink(destination:DetalhesViagemView(pacoteDeViagem: pacote)
                                        .navigationBarTitle("")
                                        .navigationBarHidden(true)
                        )
                            {
                            
                            PacotesViagensView(pacoteDeViagem: pacote)
                        }.buttonStyle(PlainButtonStyle())
                        
                    }
                    
          }
       }
    }
        .frame(height:300)
        .background(Color(red: 247.0/255.0, green: 247.0/255.0, blue: 247.0/255.0))
  }
}

struct SecaoPacoteView_Previews: PreviewProvider {
    static var previews: some View {
        SecaoPacoteView(nomeDaSecao: pacoteDeViagens[0].categoria.rawValue, pacotes: pacoteDeViagens)
            .previewLayout(.fixed(width: 600, height: 300))
    }
}
