//
//  alura_viagemApp.swift
//  alura-viagem
//
//  Created by Lucas Parreira on 12/04/21.
//

import SwiftUI

@main
struct alura_viagemApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
